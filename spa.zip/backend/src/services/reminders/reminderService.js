/**
 * Reminder Service
 * 
 * This service handles the generation and sending of reminders for upcoming appointments.
 */

const { Op } = require('sequelize');
const { Booking, Client, ServiceOption, Service, Therapist } = require('../../models');
const { addDays, format, parseISO } = require('date-fns');

/**
 * Email notification service (placeholder - would integrate with actual email provider)
 */
const sendEmail = async (to, subject, body) => {
  // In production, this would integrate with SendGrid, AWS SES, etc.
  console.log(`[EMAIL NOTIFICATION] To: ${to}, Subject: ${subject}`);
  console.log(`Body: ${body}`);
  
  // Return success for now
  return { success: true, messageId: `mock-email-${Date.now()}` };
};

/**
 * SMS notification service (placeholder - would integrate with actual SMS provider)
 */
const sendSMS = async (to, body) => {
  // In production, this would integrate with Twilio, Nexmo, etc.
  console.log(`[SMS NOTIFICATION] To: ${to}`);
  console.log(`Body: ${body}`);
  
  // Return success for now
  return { success: true, messageId: `mock-sms-${Date.now()}` };
};

/**
 * Generate email reminder content for an appointment
 */
const generateEmailContent = (booking, client, service, therapist) => {
  const appointmentDate = format(parseISO(booking.bookingStartTime), 'EEEE, MMMM d, yyyy');
  const appointmentTime = format(parseISO(booking.bookingStartTime), 'h:mm a');
  
  const subject = `Reminder: Your massage appointment on ${appointmentDate}`;
  
  const body = `
Dear ${client.firstName},

This is a friendly reminder about your upcoming appointment:

Date: ${appointmentDate}
Time: ${appointmentTime}
Service: ${service.name} (${service.duration} minutes)
${therapist ? `Therapist: ${therapist.firstName} ${therapist.lastName}` : ''}

Please arrive 10 minutes before your appointment time.
If you need to reschedule, please contact us at least 24 hours in advance.

Thank you for choosing our services!

Best regards,
The Massage Management Team
  `;
  
  return { subject, body };
};

/**
 * Generate SMS reminder content for an appointment
 */
const generateSMSContent = (booking, client, service) => {
  const appointmentDate = format(parseISO(booking.appointmentDate), 'MMM d');
  const appointmentTime = format(parseISO(booking.appointmentDate), 'h:mm a');
  
  return `Reminder: Your ${service.name} appointment is scheduled for ${appointmentDate} at ${appointmentTime}. Please arrive 10 minutes early. Reply Y to confirm.`;
};

/**
 * Find bookings that need reminders
 * @param {Object} options - Filter options
 * @param {number} options.daysAhead - Number of days ahead to check for appointments (default: 1)
 * @param {string} options.status - Booking status to filter by (default: 'confirmed')
 * @returns {Promise<Array>} - Array of bookings that need reminders
 */
const findBookingsForReminders = async (options = {}) => {
  const { daysAhead = 1, status = 'confirmed' } = options;
  
  // Calculate the date range for tomorrow
  const startDate = new Date();
  startDate.setHours(0, 0, 0, 0);
  
  const endDate = addDays(startDate, daysAhead);
  endDate.setHours(23, 59, 59, 999);
  
  // Find all confirmed bookings for the date range
  const bookings = await Booking.findAll({
    where: {
      bookingStartTime: {
        [Op.between]: [startDate, endDate]
      },
      status: status,
      reminderSent: false // Only send reminders once
    },
    include: [
      { model: Client },
      { 
        model: ServiceOption,
        include: [ Service ]  // Nested include to get Service via ServiceOption
      },
      { model: Therapist }
    ]
  });
  
  return bookings;
};

/**
 * Send reminders for upcoming appointments
 * @param {Object} options - Options for sending reminders
 * @param {number} options.daysAhead - Number of days ahead to check for appointments
 * @param {string} options.status - Booking status to filter by
 * @param {boolean} options.sendEmail - Whether to send email reminders
 * @param {boolean} options.sendSMS - Whether to send SMS reminders
 * @returns {Promise<Object>} - Results of the reminder sending operation
 */
const sendReminders = async (options = {}) => {
  const {
    daysAhead = 1,
    status = 'confirmed',
    sendEmail = true,
    sendSMS = true
  } = options;
  
  try {
    // Find bookings that need reminders
    const bookings = await findBookingsForReminders({ daysAhead, status });
    
    console.log(`Found ${bookings.length} bookings that need reminders`);
    
    const results = {
      total: bookings.length,
      emailSent: 0,
      smsSent: 0,
      errors: []
    };
    
    // Send reminders for each booking
    for (const booking of bookings) {
      const client = booking.Client;
      const therapist = booking.Therapist;
      // Access service via ServiceOption
      const service = booking.ServiceOption?.Service;

      if (!service) {
        console.warn(`Booking ${booking.id} has no associated service.`);
        continue; // Skip if no service found
      }
      
      try {
        // Send email reminder
        if (sendEmail && client.email) {
          const { subject, body } = generateEmailContent(booking, client, service, therapist);
          await sendEmail(client.email, subject, body);
          results.emailSent++;
        }
        
        // Send SMS reminder
        if (sendSMS && client.phone) {
          const smsContent = generateSMSContent(booking, client, service);
          await sendSMS(client.phone, smsContent);
          results.smsSent++;
        }
        
        // Mark reminder as sent
        await booking.update({ reminderSent: true });
      } catch (error) {
        console.error(`Error sending reminder for booking ${booking.id}:`, error);
        results.errors.push({
          bookingId: booking.id,
          clientId: client.id,
          error: error.message
        });
      }
    }
    
    return results;
  } catch (error) {
    console.error('Error in sendReminders:', error);
    throw error;
  }
};

module.exports = {
  findBookingsForReminders,
  sendReminders
};
