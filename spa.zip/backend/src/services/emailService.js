const nodemailer = require('nodemailer');
const crypto = require('crypto');
const { Booking } = require('../models');
const { format } = require('date-fns');

// Create transporter (configure based on your email service)
const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
};

// Generate unique token for consent form
const generateConsentFormToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

// Send booking confirmation email with consent form link
exports.sendBookingConfirmation = async (booking, client, serviceOption, service) => {
  try {
    const transporter = createTransporter();

    // Generate and save consent form token
    const consentFormToken = generateConsentFormToken();
    await booking.update({ consentFormToken });

    // Create consent form URL
    const consentFormUrl = `${process.env.CLIENT_URL}/consent-form/${consentFormToken}`;

    // Format booking details
    const bookingDate = format(new Date(booking.bookingStartTime), 'EEEE, MMMM do, yyyy');
    const bookingTime = format(new Date(booking.bookingStartTime), 'h:mm a');

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Booking Confirmation</title>
        <style>
          :root {
            --consent-form-url: url('${consentFormUrl}');
          }
          
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #1976d2; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          
          .button { 
            display: inline-block; 
            background-color: #1976d2; 
            color: white; 
            padding: 12px 24px; 
            text-decoration: none; 
            border-radius: 4px; 
            margin: 20px 0;
            font-weight: bold;
            position: relative;
          }
          
          /* Hide the actual URL on hover */
          .button::after {
            content: 'Click to complete your consent form';
            position: absolute;
            bottom: -25px;
            left: 0;
            background: #333;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s;
          }
          
          .button:hover::after {
            opacity: 1;
          }
          
          /* Alternative approach using JavaScript */
          .secure-button {
            display: inline-block; 
            background-color: #1976d2; 
            color: white; 
            padding: 12px 24px; 
            text-decoration: none; 
            border-radius: 4px; 
            margin: 20px 0;
            font-weight: bold;
            cursor: pointer;
          }
          
          .info-box { 
            background-color: #e3f2fd; 
            border-left: 4px solid #1976d2; 
            padding: 16px; 
            margin: 20px 0; 
          }
          .footer { 
            background-color: #333; 
            color: white; 
            padding: 20px; 
            text-align: center; 
            font-size: 14px; 
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Booking Confirmation Required</h1>
          </div>
          
          <div class="content">
            <h2>Hello ${client.firstName}!</h2>
            
            <p>Thank you for booking with us. Your appointment has been successfully submitted and is currently <strong>pending confirmation</strong>.</p>
            
            <div class="info-box">
              <h3>📋 Next Step Required</h3>
              <p>To complete your booking and confirm your appointment, please fill out our consent form by clicking the button below:</p>
              
              <!-- Method 1: Using onclick with JavaScript to hide URL -->
              <a href="#" onclick="window.open('${consentFormUrl}', '_blank'); return false;" class="secure-button">Complete Consent Form</a>
              
              <!-- Method 2: Traditional link with CSS tooltip override -->
              <!-- <a href="${consentFormUrl}" class="button" title="Complete your consent form">Complete Consent Form</a> -->
              
              <p><strong>Important:</strong> Your appointment will only be fully confirmed after you complete the consent form.</p>
            </div>
            
            <h3>Preliminary Booking Details:</h3>
            <ul>
              <li><strong>Service:</strong> ${service.name}</li>
              <li><strong>Option:</strong> ${serviceOption.optionName}</li>
              <li><strong>Date:</strong> ${bookingDate}</li>
              <li><strong>Time:</strong> ${bookingTime}</li>
              <li><strong>Duration:</strong> ${serviceOption.duration} minutes</li>
              <li><strong>Price:</strong> $${serviceOption.price}</li>
            </ul>
            
            <div class="info-box">
              <h4>⚠️ Please Note:</h4>
              <ul>
                <li>This is not your final confirmation</li>
                <li>Complete booking details will be sent after consent form submission</li>
                <li>The consent form link is valid for 48 hours</li>
              </ul>
            </div>
            
            <p>If you have any questions, please don't hesitate to contact us.</p>
            
            <p>Best regards,<br>Your Therapy Team</p>
          </div>
          
          <div class="footer">
            <p>This email was sent regarding your booking request.</p>
            <p>If you didn't make this booking, please contact us immediately.</p>
          </div>
        </div>
        
        <script>
          // Additional security: Clear the URL from browser history after click
          document.addEventListener('DOMContentLoaded', function() {
            const secureButtons = document.querySelectorAll('.secure-button');
            secureButtons.forEach(button => {
              button.addEventListener('click', function(e) {
                e.preventDefault();
                const url = '${consentFormUrl}';
                window.open(url, '_blank');
                // Clear from history
                if (history.replaceState) {
                  history.replaceState(null, null, window.location.href);
                }
              });
            });
          });
        </script>
      </body>
      </html>
    `;

    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@yourtherapy.com',
      to: client.email,
      subject: 'Booking Confirmation Required - Complete Your Consent Form',
      html: emailHtml
    };

    await transporter.sendMail(mailOptions);

    return { success: true, message: 'Booking confirmation email sent successfully' };

  } catch (error) {
    console.error('Error sending booking confirmation email:', error);
    return { success: false, error: error.message };
  }
};

// Send booking details email after consent form completion
exports.sendBookingDetailsEmail = async (booking, client, serviceOption, service) => {
  try {
    const transporter = createTransporter();

    // Format booking details
    const bookingDate = format(new Date(booking.bookingStartTime), 'EEEE, MMMM do, yyyy');
    const bookingTime = format(new Date(booking.bookingStartTime), 'h:mm a');
    const endTime = format(new Date(booking.bookingEndTime), 'h:mm a');

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Confirmed</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #1976d2; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .appointment-card { 
            background-color: white; 
            border: 2px solid #1976d2; 
            border-radius: 8px; 
            padding: 20px; 
            margin: 20px 0; 
          }
          .detail-row { 
            display: flex; 
            justify-content: space-between; 
            padding: 8px 0; 
            border-bottom: 1px solid #eee; 
          }
          .detail-row:last-child { border-bottom: none; }
          .label { font-weight: bold; color: #666; }
          .value { color: #333; }
          .important-info { 
            background-color: #fff3cd; 
            border: 1px solid #ffeaa7; 
            border-radius: 4px; 
            padding: 16px; 
            margin: 20px 0; 
          }
          .footer { 
            background-color: #333; 
            color: white; 
            padding: 20px; 
            text-align: center; 
            font-size: 14px; 
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Appointment Confirmed!</h1>
          </div>
          
          <div class="content">
            <h2>Hello ${client.firstName}!</h2>
            
            <p>Great news! Your consent form has been received and your appointment is now <strong>fully confirmed</strong>.</p>
            
            <div class="appointment-card">
              <h3 style="margin-top: 0; color: #1976d2;">📅 Your Appointment Details</h3>
              
              <div class="detail-row">
                <span class="label">Booking ID:</span>
                <span class="value">#${booking.id.substring(0, 8).toUpperCase()}</span>
              </div>
              
              <div class="detail-row">
                <span class="label">Service:</span>
                <span class="value">${service.name}</span>
              </div>
              
              <div class="detail-row">
                <span class="label">Service Option:</span>
                <span class="value">${serviceOption.optionName}</span>
              </div>
              
              <div class="detail-row">
                <span class="label">Date:</span>
                <span class="value">${bookingDate}</span>
              </div>
              
              <div class="detail-row">
                <span class="label">Time:</span>
                <span class="value">${bookingTime} - ${endTime}</span>
              </div>
              
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${serviceOption.duration} minutes</span>
              </div>
              
              <div class="detail-row">
                <span class="label">Total Price:</span>
                <span class="value"><strong>$${serviceOption.price}</strong></span>
              </div>
              
              <div class="detail-row">
                <span class="label">Payment Status:</span>
                <span class="value">${booking.paymentStatus}</span>
              </div>
            </div>
            
            <div class="important-info">
              <h4>📍 Important Information:</h4>
              <ul>
                <li><strong>Arrival:</strong> Please arrive 10 minutes before your appointment time</li>
                <li><strong>Cancellation:</strong> Please provide at least 24 hours notice for cancellations</li>
                <li><strong>Contact:</strong> Call us if you need to reschedule or have any questions</li>
                <li><strong>What to Bring:</strong> Please bring a valid ID and any relevant medical documents</li>
              </ul>
            </div>
            
            <h3>Contact Information:</h3>
            <p>
              📞 Phone: ${process.env.BUSINESS_PHONE || '(555) 123-4567'}<br>
              📧 Email: ${process.env.BUSINESS_EMAIL || 'info@yourtherapy.com'}<br>
              📍 Address: ${process.env.BUSINESS_ADDRESS || 'Your Business Address'}
            </p>
            
            <p>We look forward to seeing you at your appointment!</p>
            
            <p>Best regards,<br>Your Therapy Team</p>
          </div>
          
          <div class="footer">
            <p>This is your official appointment confirmation.</p>
            <p>Please save this email for your records.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@yourtherapy.com',
      to: client.email,
      subject: `Appointment Confirmed - ${bookingDate} at ${bookingTime}`,
      html: emailHtml
    };

    await transporter.sendMail(mailOptions);

    return { success: true, message: 'Booking details email sent successfully' };

  } catch (error) {
    console.error('Error sending booking details email:', error);
    return { success: false, error: error.message };
  }
};


exports.rescheduleBookingEmail = async (booking, client, newStartTime, newEndTime) => {
  try {
    const transporter = createTransporter();

    // Format new booking details
    const newBookingDate = format(new Date(newStartTime), 'EEEE, MMMM do, yyyy');
    const newBookingTime = format(new Date(newStartTime), 'h:mm a');
    const newEndTimeFormatted = format(new Date(newEndTime), 'h:mm a');

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Rescheduled</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #1976d2; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .appointment-card { 
            background-color: white; 
            border: 2px solid #1976d2; 
            border-radius: 8px; 
            padding: 20px; 
            margin: 20px 0; 
          }
          .detail-row { 
            display: flex; 
            justify-content: space-between; 
            padding: 8px 0; 
            border-bottom: 1px solid #eee; 
          }
          .detail-row:last-child { border-bottom: none; }
          .label { font-weight: bold; color: #666; }
          .value { color: #333; }
          .footer { 
            background-color: #333; 
            color: white; 
            padding: 20px; 
            text-align: center; 
            font-size: 14px; 
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Appointment Rescheduled</h1>
          </div>
          
          <div class="content">
            <h2>Hello ${client.firstName}!</h2>
            
            <p>Your appointment has been successfully rescheduled. Here are the updated details:</p>
            <div class="appointment-card">
              <h3 style="margin-top: 0; color: #1976d2;">📅 Rescheduled Appointment Details</h3>
              
              <div class="detail-row">
                <span class="label">Booking ID:</span>
                <span class="value">#${booking.id.substring(0, 8).toUpperCase()}</span>
              </div>
              
              <div class="detail-row">
                <span class="label">New Date:</span>
                <span class="value">${newBookingDate}</span>
              </div>
              
              <div class="detail-row">
                <span class="label">New Time:</span>
                <span class="value">${newBookingTime} - ${newEndTimeFormatted}</span>
              </div>
              <div class="detail-row">
                <span class="label">Duration:</span>
                <span class="value">${booking.serviceOption.duration} minutes</span>
              </div>
              <div class="detail-row">
                <span class="label">Total Price:</span>
                <span class="value"><strong>$${booking.serviceOption.price}</strong></span>
              </div>
              <div class="detail-row">
                <span class="label">Payment Status:</span>
                <span class="value">${booking.paymentStatus}</span> 
              </div>
            </div>
            <p>If you have any questions or need to make further changes, please don't hesitate to contact us.</p>
            <p>Thank you for choosing us!</p>
            <p>Best regards,<br>Your Therapy Team</p>
          </div>
           <div class="important-info">
              <h4>📍 Important Information:</h4>
              <ul>
                <li><strong>Arrival:</strong> Please arrive 10 minutes before your appointment time</li>
                <li><strong>Cancellation:</strong> Please provide at least 24 hours notice for cancellations</li>
                <li><strong>Contact:</strong> Call us if you need to reschedule or have any questions</li>
                <li><strong>What to Bring:</strong> Please bring a valid ID and any relevant medical documents</li>
              </ul>
            </div>
            
            <h3>Contact Information:</h3>
            <p>
              📞 Phone: ${process.env.BUSINESS_PHONE || '(555) 123-4567'}<br>
              📧 Email: ${process.env.BUSINESS_EMAIL || 'info@yourtherapy.com'}<br>
              📍 Address: ${process.env.BUSINESS_ADDRESS || 'Your Business Address'}
            </p>
            
            <p>We look forward to seeing you at your appointment!</p>
            
            <p>Best regards,<br>Your Therapy Team</p>
          </div>
          
          <div class="footer">
            <p>This is your official appointment confirmation.</p>
            <p>Please save this email for your records.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@yourtherapy.com',
      to: client.email,
      subject: `Appointment Confirmed - ${bookingDate} at ${bookingTime}`,
      html: emailHtml
    };

    await transporter.sendMail(mailOptions);

    return { success: true, message: 'Booking details email sent successfully' };

  } catch (error) {
    console.error('Error sending booking details email:', error);
    return { success: false, error: error.message };
  }
};
// Send cancellation email to client
exports.sendCancellationEmail = async (booking, client) => {
  try {
    const transporter = createTransporter();

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment Cancelled</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #d32f2f; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .footer { 
            background-color: #333; 
            color: white; 
            padding: 20px; 
            text-align: center; 
            font-size: 14px; 
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Appointment Cancelled</h1>
          </div>
          
          <div class="content">
            <h2>Hello ${client.firstName},</h2>
            
            <p>We regret to inform you that your appointment scheduled for ${booking.bookingStartTime} has been cancelled.</p>
            
            <p>If you have any questions or would like to reschedule, please contact us at your earliest convenience.</p>
            
            <p>Thank you for your understanding.</p>
            
            <p>Best regards,<br>Your Therapy Team</p>
          </div>
          
          <div class="footer">
            <p>This is a notification regarding your appointment cancellation.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    const mailOptions = {
      from: process.env.EMAIL_FROM || 'noreply@mail.com',
      to: client.email,
      subject: 'Your Appointment Has Been Cancelled',
      html: emailHtml
    };
    await transporter.sendMail(mailOptions);
    return { success: true, message: 'Cancellation email sent successfully' };
  }
  catch (error) {
    console.error('Error sending cancellation email:', error);
    return { success: false, error: error.message };
  }
}