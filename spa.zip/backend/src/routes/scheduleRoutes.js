const express = require("express");
const { body, param, query } = require("express-validator");
const scheduleController = require("../controllers/scheduleController");
const { authenticateToken, authorizeRole } = require("../middleware/authMiddleware");
const { validateRequest } = require("../middleware/validationMiddleware");

const router = express.Router();

// --- Admin/Staff Routes ---

// GET /api/v1/schedule - Get schedule for a specific therapist or all (Admin/Staff)
router.get(
    "/",
    authenticateToken,
    authorizeRole(["admin", "staff"]),
    [
        query("therapistId").optional().isUUID().withMessage("Therapist ID must be a valid UUID"),
        query("startDate").optional().isISO8601().toDate().withMessage("Valid start date is required (YYYY-MM-DD)"),
        query("endDate").optional().isISO8601().toDate().withMessage("Valid end date is required (YYYY-MM-DD)"),
        query("page").optional().isInt({ min: 1 }).withMessage("Page must be a positive integer"),
        query("limit").optional().isInt({ min: 1, max: 100 }).withMessage("Limit must be between 1 and 100"),
        query("type").optional().isIn(["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"]).withMessage("Type must be one of: WorkingHours, TimeOff, SpecificAvailability, BlockedSlot"),
    ],
    validateRequest,
    scheduleController.getSchedules
);

// GET /api/v1/schedule/conflicts - Check for schedule conflicts (Admin/Staff)
router.get(
    "/conflicts",
    authenticateToken,
    authorizeRole(["admin", "staff"]),
    [
        query("therapistId").isUUID().withMessage("Therapist ID must be a valid UUID"),
        query("startTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid start time is required (HH:mm:ss format)"),
        query("endTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid end time is required (HH:mm:ss format)"),
        query("specificDate").optional().isISO8601().withMessage("Valid specific date is required (YYYY-MM-DD format)"),
        query("dayOfWeek").optional().isInt({ min: 0, max: 6 }).withMessage("Day of week must be between 0 and 6"),
        query("excludeId").optional().isUUID().withMessage("Exclude ID must be a valid UUID"),
    ],
    validateRequest,
    scheduleController.checkConflicts
);

// POST /api/v1/schedule - Add schedule entry for a therapist (Admin/Staff)
router.post(
    "/",
    authenticateToken,
    authorizeRole(["admin", "staff"]),
    [
        body("therapistId").isUUID().withMessage("Therapist ID must be a valid UUID"),
        body("type").isIn(["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"]).withMessage("Type must be one of: WorkingHours, TimeOff, SpecificAvailability, BlockedSlot"),
        body("startTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid start time is required (HH:mm:ss format)"),
        body("endTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid end time is required (HH:mm:ss format)"),
        body("dayOfWeek").optional().isInt({ min: 0, max: 6 }).withMessage("Day of week must be between 0 and 6"),
        body("specificDate").optional().isISO8601().withMessage("Valid specific date is required (YYYY-MM-DD format)"),
        body("recurrenceStartDate").optional().isISO8601().withMessage("Valid recurrence start date is required (YYYY-MM-DD format)"),
        body("recurrenceEndDate").optional().isISO8601().withMessage("Valid recurrence end date is required (YYYY-MM-DD format)"),
        body("notes").optional().isString().isLength({ max: 1000 }).withMessage("Notes must be a string with max 1000 characters"),
    ],
    validateRequest,
    scheduleController.createScheduleEntry
);

// PUT /api/v1/schedule/:id - Update a schedule entry (Admin/Staff)
router.put(
    "/:id",
    authenticateToken,
    authorizeRole(["admin", "staff"]),
    [
        param("id").isUUID().withMessage("Schedule entry ID must be a valid UUID"),
        body("type").optional().isIn(["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"]).withMessage("Type must be one of: WorkingHours, TimeOff, SpecificAvailability, BlockedSlot"),
        body("startTime").optional().matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid start time is required (HH:mm:ss format)"),
        body("endTime").optional().matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid end time is required (HH:mm:ss format)"),
        body("dayOfWeek").optional().isInt({ min: 0, max: 6 }).withMessage("Day of week must be between 0 and 6"),
        body("specificDate").optional().isISO8601().withMessage("Valid specific date is required (YYYY-MM-DD format)"),
        body("recurrenceStartDate").optional().isISO8601().withMessage("Valid recurrence start date is required (YYYY-MM-DD format)"),
        body("recurrenceEndDate").optional().isISO8601().withMessage("Valid recurrence end date is required (YYYY-MM-DD format)"),
        body("notes").optional().isString().isLength({ max: 1000 }).withMessage("Notes must be a string with max 1000 characters"),
    ],
    validateRequest,
    scheduleController.updateScheduleEntry
);

// DELETE /api/v1/schedule/:id - Delete a schedule entry (Admin/Staff)
router.delete(
    "/:id",
    authenticateToken,
    authorizeRole(["admin", "staff"]),
    [param("id").isUUID().withMessage("Schedule entry ID must be a valid UUID")],
    validateRequest,
    scheduleController.deleteScheduleEntry
);

// --- Therapist Routes ---

// GET /api/v1/schedule/me - Get own schedule (Therapist)
router.get(
    "/me",
    authenticateToken,
    authorizeRole(["therapist"]),
    [
        query("startDate").optional().isISO8601().toDate().withMessage("Valid start date is required (YYYY-MM-DD)"),
        query("endDate").optional().isISO8601().toDate().withMessage("Valid end date is required (YYYY-MM-DD)"),
    ],
    validateRequest,
    scheduleController.getMySchedules
);

// GET /api/v1/schedule/me/conflicts - Check for own schedule conflicts (Therapist)
router.get(
    "/me/conflicts",
    authenticateToken,
    authorizeRole(["therapist"]),
    [
        query("startTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid start time is required (HH:mm:ss format)"),
        query("endTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid end time is required (HH:mm:ss format)"),
        query("specificDate").optional().isISO8601().withMessage("Valid specific date is required (YYYY-MM-DD format)"),
        query("dayOfWeek").optional().isInt({ min: 0, max: 6 }).withMessage("Day of week must be between 0 and 6"),
        query("excludeId").optional().isUUID().withMessage("Exclude ID must be a valid UUID"),
    ],
    validateRequest,
    scheduleController.checkMyConflicts
);

// POST /api/v1/schedule/me - Add own schedule entry (Therapist)
router.post(
    "/me",
    authenticateToken,
    authorizeRole(["therapist"]),
    [
        body("type").isIn(["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"]).withMessage("Type must be one of: WorkingHours, TimeOff, SpecificAvailability, BlockedSlot"),
        body("startTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid start time is required (HH:mm:ss format)"),
        body("endTime").matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid end time is required (HH:mm:ss format)"),
        body("dayOfWeek").optional().isInt({ min: 0, max: 6 }).withMessage("Day of week must be between 0 and 6"),
        body("specificDate").optional().isISO8601().withMessage("Valid specific date is required (YYYY-MM-DD format)"),
        body("recurrenceStartDate").optional().isISO8601().withMessage("Valid recurrence start date is required (YYYY-MM-DD format)"),
        body("recurrenceEndDate").optional().isISO8601().withMessage("Valid recurrence end date is required (YYYY-MM-DD format)"),
        body("notes").optional().isString().isLength({ max: 1000 }).withMessage("Notes must be a string with max 1000 characters"),
    ],
    validateRequest,
    scheduleController.addMyScheduleEntry
);

// PUT /api/v1/schedule/me/:id - Update own schedule entry (Therapist)
router.put(
    "/me/:id",
    authenticateToken,
    authorizeRole(["therapist"]),
    [
        param("id").isUUID().withMessage("Schedule entry ID must be a valid UUID"),
        body("type").optional().isIn(["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"]).withMessage("Type must be one of: WorkingHours, TimeOff, SpecificAvailability, BlockedSlot"),
        body("startTime").optional().matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid start time is required (HH:mm:ss format)"),
        body("endTime").optional().matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/).withMessage("Valid end time is required (HH:mm:ss format)"),
        body("dayOfWeek").optional().isInt({ min: 0, max: 6 }).withMessage("Day of week must be between 0 and 6"),
        body("specificDate").optional().isISO8601().withMessage("Valid specific date is required (YYYY-MM-DD format)"),
        body("recurrenceStartDate").optional().isISO8601().withMessage("Valid recurrence start date is required (YYYY-MM-DD format)"),
        body("recurrenceEndDate").optional().isISO8601().withMessage("Valid recurrence end date is required (YYYY-MM-DD format)"),
        body("notes").optional().isString().isLength({ max: 1000 }).withMessage("Notes must be a string with max 1000 characters"),
    ],
    validateRequest,
    scheduleController.updateMyScheduleEntry
);

// DELETE /api/v1/schedule/me/:id - Delete own schedule entry (Therapist)
router.delete(
    "/me/:id",
    authenticateToken,
    authorizeRole(["therapist"]),
    [param("id").isUUID().withMessage("Schedule entry ID must be a valid UUID")],
    validateRequest,
    scheduleController.deleteMyScheduleEntry
);

module.exports = router;

