const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Payment = sequelize.define("Payment", {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  bookingId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "Bookings",
      key: "id",
    },
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  currency: {
    type: DataTypes.STRING(3), // e.g., "USD", "EUR"
    allowNull: false,
    defaultValue: "USD",
  },
  method: {
    type: DataTypes.ENUM("Credit Card", "Insurance", "Cash", "Other"),
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM("Pending", "Succeeded", "Failed", "Refunded"),
    allowNull: false,
    defaultValue: "Pending",
  },
  // Store external transaction ID (e.g., Stripe Charge ID)
  transactionId: {
    type: DataTypes.STRING,
    allowNull: true, // May not apply to Cash/Other, or might be set later
    unique: true,
  },
  // Store details from the payment provider if needed
  // providerDetails: {
  //   type: DataTypes.JSONB, // Use JSONB for flexible storage of provider response
  //   allowNull: true,
  // },
   providerDetails: {
    type: DataTypes.JSON, // Use JSON for flexible storage of provider response
    allowNull: true,
  },
  // Insurance specific fields (if payment method is Insurance)
  insuranceProvider: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  insurancePolicyId: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  paidAt: {
    type: DataTypes.DATE,
    allowNull: true, // Set when payment status becomes Succeeded
  },
}, {
  timestamps: true, // Track when payment record was created/updated
  indexes: [
    { fields: ["bookingId"] },
    { fields: ["transactionId"] },
    { fields: ["status"] },
  ],
});

module.exports = Payment;

