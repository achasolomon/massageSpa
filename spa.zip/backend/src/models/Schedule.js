const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Schedule = sequelize.define("Schedule", {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  therapistId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: "Therapists",
      key: "id",
    },
  },
  // Type of schedule entry: "WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"
  type: {
    type: DataTypes.ENUM("WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"),
    allowNull: false,
  },
  // For recurring entries like standard working hours
  dayOfWeek: {
    type: DataTypes.INTEGER, // 0 (Sunday) to 6 (Saturday)
    allowNull: true, // Null for specific date entries
  },
  // For specific date entries like time off or specific availability
  specificDate: {
    type: DataTypes.DATEONLY,
    allowNull: true, // Null for recurring weekly entries
  },
  startTime: {
    type: DataTypes.TIME, // e.g., "09:00:00"
    allowNull: false,
  },
  endTime: {
    type: DataTypes.TIME, // e.g., "17:00:00"
    allowNull: false,
  },
  // Optional: For recurring entries, specify start/end dates for the recurrence
  recurrenceStartDate: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  recurrenceEndDate: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
}, {
  timestamps: true,
  indexes: [
    { fields: ["therapistId", "dayOfWeek"] },
    { fields: ["therapistId", "specificDate"] },
    { fields: ["therapistId", "type"] },
  ],
});

module.exports = Schedule;

