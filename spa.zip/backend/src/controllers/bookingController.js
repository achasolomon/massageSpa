const { Op, fn, col, literal } = require("sequelize");
const { Booking, Client, Service, ClinicalNote, ServiceOption, ServiceAvailability, Therapist, User, sequelize, Payment } = require("../models");
const { format, parseISO, addMinutes, startOfDay, endOfDay, eachMinuteOfInterval, isWithinInterval, parse, isValid } = require("date-fns");
const { sendBookingConfirmation, sendBookingDetailsEmail } = require("../services/emailService"); // Add this import
const { parseBookingTime } = require('../utils/bookingTime');

// Helper function to get or create a client
async function findOrCreateClient(clientInfo, transaction) {
  const { email, firstName, lastName, phone } = clientInfo;
  let client = await Client.findOne({ where: { email }, transaction });
  if (!client) {
    client = await Client.create({ email, firstName, lastName, phone }, { transaction });
  }
  return client;
}

// Get Available Time Slots (Refactored for ServiceAvailability and Slot Limits)
exports.checkAvailability = async (req, res) => {
  const { date, serviceOptionId, therapistId } = req.query;

  if (!date || !serviceOptionId) {
    return res.status(400).json({ message: "Date and Service Option ID are required." });
  }

  try {
    const targetDate = parseISO(date);
    if (!isValid(targetDate)) {
      return res.status(400).json({ message: "Invalid date format. Please use YYYY-MM-DD." });
    }
    const targetDateStart = startOfDay(targetDate);
    const targetDateEnd = endOfDay(targetDate);
    const dayNum = targetDate.getDay(); // 0 = Sunday, 6 = Saturday

    // 1. Get Service Option details (includes duration and serviceId)
    const serviceOption = await ServiceOption.findByPk(serviceOptionId, {
      include: { model: Service, attributes: ["id", "name"] }
    });
    if (!serviceOption || !serviceOption.isActive || !serviceOption.Service?.isActive) {
      return res.status(404).json({ message: "Service option not found or inactive." });
    }
    const serviceId = serviceOption.serviceId;
    const serviceDuration = serviceOption.duration;

    // 2. Find relevant ServiceAvailability rules
    const availabilityWhere = {
      serviceId: serviceId,
      isActive: true,
      [Op.or]: [
        { specificDate: date },
        { dayOfWeek: dayNum, specificDate: null }
      ]
    };
    if (therapistId && therapistId !== "any") {
      availabilityWhere.therapistId = therapistId;
    } // If therapistId is null/"any", we consider rules with therapistId=null OR rules for specific therapists

    const availabilityRules = await ServiceAvailability.findAll({
      where: availabilityWhere,
      include: [{ model: Therapist, include: [{ model: User, attributes: ["firstName", "lastName"] }], required: false }],
      order: [["startTime", "ASC"]]
    });

    if (availabilityRules.length === 0) {
      return res.json([]); // No availability rules found for this service/date/therapist combination
    }

    // 3. Get existing bookings for the target date and relevant slots/therapists
    const relevantTherapistIds = [...new Set(availabilityRules.map(rule => rule.therapistId).filter(id => id !== null))];
    const bookingWhere = {
      serviceOptionId: serviceOptionId, // Match the specific option being booked
      bookingStartTime: {
        [Op.between]: [targetDateStart, targetDateEnd]
      },
      status: { [Op.notIn]: ["Cancelled By Client", "Cancelled By Staff"] }
    };
    // If a specific therapist is requested, only check their bookings
    // If "any", check bookings for all relevant therapists + bookings with therapistId=null (if applicable)
    if (therapistId && therapistId !== "any") {
      bookingWhere.therapistId = therapistId;
    } else if (relevantTherapistIds.length > 0) {
      bookingWhere.therapistId = { [Op.in]: relevantTherapistIds };
      // Consider adding check for bookings where therapistId is NULL if rules allow it?
    }

    const existingBookings = await Booking.findAll({
      where: bookingWhere,
      attributes: ["therapistId", "bookingStartTime", [fn("COUNT", col("id")), "bookingCount"]],
      group: ["therapistId", "bookingStartTime"]
    });

    // Create a map for quick lookup of booking counts per slot
    const bookingCounts = {}; // Key: "HH:MM:SS_therapistId" (or "HH:MM:SS_null"), Value: count
    existingBookings.forEach(booking => {
      const timeStr = format(new Date(booking.bookingStartTime), "HH:mm:ss");
      const key = `${timeStr}_${booking.therapistId || "null"}`;
      bookingCounts[key] = parseInt(booking.get("bookingCount"), 10);
    });

    // 4. Determine available slots based on rules and booking counts
    const availableSlots = [];
    const addedSlots = new Set(); // To avoid duplicates if multiple rules match the same time

    for (const rule of availabilityRules) {
      const slotTime = rule.startTime; // Format HH:MM:SS
      const slotKey = `${slotTime}_${rule.therapistId || "null"}`;
      const currentBookings = bookingCounts[slotKey] || 0;

      if (currentBookings < rule.bookingLimit) {
        // If therapist is "any", we just need the time. If specific, we already filtered.
        const displayTime = format(parse(slotTime, "HH:mm:ss", new Date()), "HH:mm"); // Format for frontend
        if (!addedSlots.has(displayTime)) {
          availableSlots.push(displayTime);
          addedSlots.add(displayTime);
        }
      }
    }

    res.json(availableSlots.sort());

  } catch (error) {
    console.error("Error fetching availability:", error);
    res.status(500).json({ message: "Server error while fetching availability." });
  }
};

// Create a new booking (Refactored for ServiceOption and Slot Limits)
exports.createBooking = async (req, res) => {
  console.log('RAW req.body:', req.body);

  const { serviceOptionId, bookingTime, clientDetails, clientId, paymentMethod, paymentDetails, therapistId, clientNotes } = req.body;

  // --- Basic Validation ---
  if (!serviceOptionId || !bookingTime) {
    return res.status(400).json({ message: "Service Option ID and booking time (YYYY-MM-DDTHH:MM:SSZ) are required." });
  }
  if (!clientId && (!clientDetails || !clientDetails.email || !clientDetails.firstName || !clientDetails.lastName || !clientDetails.phone)) {
    return res.status(400).json({ message: "Either Client ID or full Client Details are required." });
  }
  if (!paymentMethod) {
    return res.status(400).json({ message: "Payment method is required." });
  }

  const transaction = await sequelize.transaction(); // Start transaction

  try {
    // 1. Find or Create Client
    let client;
    if (clientId) {
      client = await Client.findByPk(clientId, { transaction });
      if (!client) {
        await transaction.rollback();
        return res.status(404).json({ message: "Client not found." });
      }
    } else {
      client = await findOrCreateClient(clientDetails, transaction);
    }

    // 2. Get Service Option Details
    const serviceOption = await ServiceOption.findByPk(serviceOptionId, {
      include: { model: Service, attributes: ["id", "name"] },
      transaction
    }); 
    if (!serviceOption || !serviceOption.isActive) {
      await transaction.rollback();
      return res.status(404).json({ message: "Service option not found or is inactive." });
    }
    const serviceId = serviceOption.serviceId;
    const priceAtBooking = serviceOption.price;
    const serviceDuration = serviceOption.duration;

    // 3. Parse and Calculate Start/End Times - FIXED
    console.log('typeof bookingTime:', typeof bookingTime, bookingTime);
    
    let bookingStart;
    
    // Better date parsing logic
    if (bookingTime instanceof Date) {
      bookingStart = bookingTime;
    } else if (typeof bookingTime === 'string') {
      bookingStart = parseISO(bookingTime);
    } else if (bookingTime && bookingTime.constructor && bookingTime.constructor.name === 'Date') {
      // Handle Date-like objects from JSON parsing
      bookingStart = new Date(bookingTime);
    } else {
      await transaction.rollback();
      return res.status(400).json({ message: "Invalid booking time type." });
    }

    if (!isValid(bookingStart)) {
      await transaction.rollback();
      return res.status(400).json({ message: "Invalid booking time format. Use ISO8601 format (YYYY-MM-DDTHH:MM:SSZ)." });
    }

    console.log('Parsed bookingStart (UTC):', bookingStart.toISOString());
    console.log('Parsed bookingStart (Local):', bookingStart.toLocaleString());

    const bookingEnd = addMinutes(bookingStart, serviceDuration);
    
    // FIXED: Use UTC methods to avoid timezone conversion issues
    const bookingDateStr = bookingStart.toISOString().split('T')[0]; // YYYY-MM-DD in UTC
    
    // FIXED: Format time in UTC to match database storage
    const utcHours = bookingStart.getUTCHours();
    const utcMinutes = bookingStart.getUTCMinutes();
    const utcSeconds = bookingStart.getUTCSeconds();
    const bookingStartTimeStr = `${utcHours.toString().padStart(2, '0')}:${utcMinutes.toString().padStart(2, '0')}:${utcSeconds.toString().padStart(2, '0')}`;
    
    // FIXED: Use UTC day to match database storage
    const bookingDayNum = bookingStart.getUTCDay(); // 0 = Sunday, 1 = Monday, etc.

    console.log('Booking details:', {
      dateStr: bookingDateStr,
      timeStr: bookingStartTimeStr,
      dayNum: bookingDayNum,
      utcTime: bookingStart.toISOString()
    });

    // 4. Determine Target Therapist (if "any") and Validate Availability Rule
    let assignedTherapistId = (therapistId && therapistId !== "any") ? therapistId : null;
    let availabilityRule = null;

    const availabilityWhere = {
      serviceId: serviceId,
      isActive: true,
      startTime: bookingStartTimeStr,
      [Op.or]: [
        { specificDate: bookingDateStr },
        { dayOfWeek: bookingDayNum, specificDate: null }
      ]
    };
    
    if (assignedTherapistId) {
      availabilityWhere.therapistId = assignedTherapistId;
    }

    console.log('Availability query conditions:', availabilityWhere);

    const potentialRules = await ServiceAvailability.findAll({
      where: availabilityWhere,
      order: [["therapistId", "DESC"]], // Prioritize therapist-specific rules over null
      transaction
    });

    console.log('Found availability rules:', potentialRules.length);
    console.log('Rules details:', potentialRules.map(rule => ({
      id: rule.id,
      therapistId: rule.therapistId,
      startTime: rule.startTime,
      dayOfWeek: rule.dayOfWeek,
      specificDate: rule.specificDate,
      bookingLimit: rule.bookingLimit
    })));

    if (potentialRules.length === 0) {
      await transaction.rollback();
      
      // DEBUG: Let's see what availability rules exist for this service
      const debugRules = await ServiceAvailability.findAll({
        where: {
          serviceId: serviceId,
          isActive: true
        },
        transaction
      });
      
      console.log('All available rules for this service:', debugRules.map(rule => ({
        startTime: rule.startTime,
        dayOfWeek: rule.dayOfWeek,
        specificDate: rule.specificDate,
        therapistId: rule.therapistId
      })));
      
      return res.status(400).json({ 
        message: "No availability rule found for the selected service, time, and therapist.",
        debug: {
          searchedFor: {
            serviceId,
            startTime: bookingStartTimeStr,
            dayOfWeek: bookingDayNum,
            specificDate: bookingDateStr
          },
          availableRules: debugRules.map(rule => ({
            startTime: rule.startTime,
            dayOfWeek: rule.dayOfWeek,
            specificDate: rule.specificDate
          }))
        }
      });
    }

    // Select the first matching rule (prioritizing therapist-specific)
    availabilityRule = potentialRules[0];
    // If therapist was "any", assign the therapist from the rule (if specified)
    if (!assignedTherapistId && availabilityRule.therapistId) {
      assignedTherapistId = availabilityRule.therapistId;
    }

    // 5. Check Booking Limit
    const currentBookingCount = await Booking.count({
      where: {
        serviceOptionId: serviceOptionId,
        bookingStartTime: bookingStart,
        therapistId: assignedTherapistId,
        status: { [Op.notIn]: ["Cancelled By Client", "Cancelled By Staff"] }
      },
      transaction
    });

    console.log('Current booking count:', currentBookingCount, 'Limit:', availabilityRule.bookingLimit);

    if (currentBookingCount >= availabilityRule.bookingLimit) {
      await transaction.rollback();
      return res.status(400).json({ message: "Sorry, this time slot is now fully booked." });
    }

    // 6. Create Booking Record
    const newBooking = await Booking.create({
      clientId: client.id,
      serviceOptionId: serviceOptionId,
      therapistId: assignedTherapistId,
      bookingStartTime: bookingStart,
      bookingEndTime: bookingEnd,
      status: "Pending Confirmation",
      clientNotes: clientNotes,
      paymentMethod: paymentMethod,
      paymentStatus: "Pending",
      priceAtBooking: priceAtBooking,
    }, { transaction });

    // 7. Handle Payment (unchanged)
    let paymentResult = { status: "Not Applicable", paymentRecord: null };
    if (paymentMethod === "Credit Card" || paymentMethod === "credit_card") {
      newBooking.paymentStatus = "Paid";
      await newBooking.save({ transaction });
    } else if (paymentMethod === "Insurance" || paymentMethod === "insurance") {
      paymentResult.paymentRecord = await Payment.create({
        bookingId: newBooking.id,
        amount: priceAtBooking,
        method: "Insurance",
        status: "Pending",
        insuranceProvider: paymentDetails?.provider,
        insurancePolicyId: paymentDetails?.policyId,
      }, { transaction });
      newBooking.paymentStatus = "Pending";
      await newBooking.save({ transaction });
    } else {
      newBooking.paymentStatus = "Pending";
      await newBooking.save({ transaction });
    }

    // 8. Commit Transaction
    await transaction.commit();

    try {
      const emailResult = await sendBookingConfirmation(
        newBooking,
        client,
        serviceOption,
        serviceOption.Service
      );

      if (!emailResult.success) {
        console.warn('Email sending failed, but booking was created successfully:', emailResult.error);
      }
    } catch (emailError) {
      console.error('Error sending confirmation email:', emailError);
    }

    // 10. Respond to Client
    res.status(201).json({
      success: true,
      message: "Booking created successfully. A confirmation email has been sent.",
      bookingId: newBooking.id,
      paymentStatus: newBooking.paymentStatus,
    });

  } catch (error) {
    await transaction.rollback();
    console.error("Error creating booking:", error);
    if (error.name === "SequelizeValidationError" || error.name === "SequelizeUniqueConstraintError") {
      const messages = error.errors ? error.errors.map(err => err.message) : [error.message];
      return res.status(400).json({ message: "Validation Error", errors: messages });
    }
    res.status(500).json({ message: "Server error while creating booking." });
  }
};

// Get All Bookings (Admin/Staff) - Updated to include ServiceOption
exports.getAllBookings = async (req, res) => {
  const { page = 1, limit = 10, status, therapistId, clientId, startDate, endDate } = req.query;
  const offset = (page - 1) * limit;
  const whereClause = {};

  // If therapist, only allow access to their own bookings
  if (req.user.role === 'therapist') {
    // Get therapist profile for this user
    const therapistProfile = await Therapist.findOne({ where: { userId: req.user.id } });
    if (!therapistProfile) {
      return res.status(403).json({ message: "Forbidden: Therapist profile not found." });
    }
    whereClause.therapistId = therapistProfile.id;
  } else {
    // Admin/staff can filter by therapistId if provided
    if (therapistId) whereClause.therapistId = therapistId;
  }

  if (status) whereClause.status = status;
  if (clientId) whereClause.clientId = clientId;
  if (startDate && endDate) {
    whereClause.bookingStartTime = {
      [Op.between]: [startOfDay(parseISO(startDate)), endOfDay(parseISO(endDate))]
    };
  } else if (startDate) {
    whereClause.bookingStartTime = { [Op.gte]: startOfDay(parseISO(startDate)) };
  } else if (endDate) {
    whereClause.bookingStartTime = { [Op.lte]: endOfDay(parseISO(endDate)) };
  }

  try {
    const { count, rows } = await Booking.findAndCountAll({
      where: whereClause,
      include: [
        { model: Client, attributes: ["id", "firstName", "lastName", "email"] },
        { model: ServiceOption, include: [{ model: Service, attributes: ["id", "name"] }] },
        { model: Therapist, include: [{ model: User, attributes: ["firstName", "lastName"] }], required: false }
      ],
      order: [["bookingStartTime", "DESC"]],
      limit: parseInt(limit),
      offset: parseInt(offset),
      distinct: true,
    });

    res.json({
      totalBookings: count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page),
      bookings: rows,
    });
  } catch (error) {
    console.error("Error fetching all bookings:", error);
    res.status(500).json({ message: "Server error while fetching bookings." });
  }
};

// Get Booking By ID - Updated to include ServiceOption
exports.getBookingById = async (req, res) => {
  const { id } = req.params;
  const requestingUser = req.user; // From authenticateToken middleware

  try {
    const booking = await Booking.findByPk(id, {
      include: [
        { model: Client },
        { model: ServiceOption, include: [{ model: Service }] },
        { model: Therapist, include: [{ model: User, attributes: ["id", "firstName", "lastName"] }], required: false },
        { model: Payment }
      ]
    });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found." });
    }

    // Authorization check: Admin/Staff can view any booking.
    // Therapist can only view bookings assigned to them.
    if (requestingUser.role === 'therapist') {
      const therapistProfile = await Therapist.findOne({ where: { userId: requestingUser.id } });
      // Allow if therapist profile exists AND booking has no therapist OR booking therapist matches
      if (!therapistProfile || (booking.therapistId && booking.therapistId !== therapistProfile.id)) {
        return res.status(403).json({ message: "Forbidden: You can only view bookings assigned to you." });
      }
    }

    res.json(booking);
  } catch (error) {
    console.error("Error fetching booking by ID:", error);
    res.status(500).json({ message: "Server error while fetching booking." });
  }
};


// Get therapist's bookings
exports.getTherapistBookings = async (req, res) => {
  try {
    const { therapistId } = req.params;
    const { page = 1, limit = 10, status, startDate, endDate, hasCompletedNote = null } = req.query;
    const offset = (page - 1) * limit;

    // Check if user has permission to view these bookings
    if (req.user.role !== 'admin' && req.user.role !== 'staff') {
      if (req.user.role === 'therapist' && therapistId !== req.user.id) {
        return res.status(403).json({ message: 'You do not have permission to view these bookings' });
      }
    }

    // Build the where clause
    const where = {
      therapistId
    };

    // Add status filter if provided
    if (status) {
      where.status = status;
    }

    // Add date range filter if provided
    if (startDate || endDate) {
      where.startTime = {};
      if (startDate) {
        where.startTime[Op.gte] = new Date(startDate);
      }
      if (endDate) {
        where.startTime[Op.lte] = new Date(endDate);
      }
    }

    // Include options for the query
    const includeOptions = [
      {
        model: Client,
        as: 'client',
        include: {
          model: User,
          as: 'user',
          attributes: ['firstName', 'lastName', 'email']
        }
      },
      {
        model: Service,
        as: 'service',
        attributes: ['id', 'name', 'description', 'duration', 'price']
      }
    ];

    // Add clinical note include with condition if hasCompletedNote is specified
    if (hasCompletedNote !== null) {
      includeOptions.push({
        model: ClinicalNote,
        as: 'clinicalNote',
        required: false
      });

      // Filter based on whether the booking has a completed clinical note
      if (hasCompletedNote === 'true') {
        includeOptions[includeOptions.length - 1].where = { completed: true };
      } else if (hasCompletedNote === 'false') {
        includeOptions[includeOptions.length - 1].where = {
          [Op.or]: [
            { completed: false },
            { id: null }
          ]
        };
      }
    } else {
      // Always include clinical note information
      includeOptions.push({
        model: ClinicalNote,
        as: 'clinicalNote',
        required: false,
        attributes: ['id', 'completed']
      });
    }

    // Get bookings with pagination
    const { count, rows: bookings } = await Booking.findAndCountAll({
      where,
      include: includeOptions,
      limit: parseInt(limit),
      offset: offset,
      order: [['startTime', 'DESC']],
      distinct: true
    });

    return res.status(200).json({
      bookings,
      total: count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    console.error('Error getting therapist bookings:', error);
    return res.status(500).json({ message: 'Failed to get bookings' });
  }
};

// Get client's bookings
exports.getClientBookings = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { page = 1, limit = 10, status, startDate, endDate } = req.query;
    const offset = (page - 1) * limit;

    // Check if user has permission to view these bookings
    if (req.user.role !== 'admin' && req.user.role !== 'staff' && req.user.role !== 'therapist') {
      if (req.user.role === 'client' && clientId !== req.user.id) {
        return res.status(403).json({ message: 'You do not have permission to view these bookings' });
      }
    }

    // Build the where clause
    const where = {
      clientId
    };

    // Add status filter if provided
    if (status) {
      where.status = status;
    }

    // Add date range filter if provided
    if (startDate || endDate) {
      where.startTime = {};
      if (startDate) {
        where.startTime[Op.gte] = new Date(startDate);
      }
      if (endDate) {
        where.startTime[Op.lte] = new Date(endDate);
      }
    }

    // Get bookings with pagination
    const { count, rows: bookings } = await Booking.findAndCountAll({
      where,
      include: [
        {
          model: Therapist,
          as: 'therapist',
          include: {
            model: User,
            as: 'user',
            attributes: ['firstName', 'lastName', 'email']
          }
        },
        {
          model: Service,
          as: 'service',
          attributes: ['id', 'name', 'description', 'duration', 'price']
        },
        {
          model: ClinicalNote,
          as: 'clinicalNote',
          attributes: ['id', 'completed']
        }
      ],
      limit: parseInt(limit),
      offset: offset,
      order: [['startTime', 'DESC']]
    });

    return res.status(200).json({
      bookings,
      total: count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    console.error('Error getting client bookings:', error);
    return res.status(500).json({ message: 'Failed to get bookings' });
  }
};

// Get a single booking
exports.getBookingById = async (req, res) => {
  try {
    const { id } = req.params;

    // Get the booking
    const booking = await Booking.findByPk(id, {
      include: [
        {
          model: Client,
          as: 'client',
          include: {
            model: User,
            as: 'user',
            attributes: ['firstName', 'lastName', 'email']
          }
        },
        {
          model: Therapist,
          as: 'therapist',
          include: {
            model: User,
            as: 'user',
            attributes: ['firstName', 'lastName', 'email']
          }
        },
        {
          model: Service,
          as: 'service',
          attributes: ['id', 'name', 'description', 'duration', 'price']
        },
        {
          model: ClinicalNote,
          as: 'clinicalNote',
          attributes: ['id', 'completed']
        }
      ]
    });

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    // Check if user has permission to view this booking
    if (req.user.role !== 'admin' && req.user.role !== 'staff') {
      if (req.user.role === 'therapist' && booking.therapistId !== req.user.id) {
        return res.status(403).json({ message: 'You do not have permission to view this booking' });
      }
      if (req.user.role === 'client' && booking.clientId !== req.user.id) {
        return res.status(403).json({ message: 'You do not have permission to view this booking' });
      }
    }

    return res.status(200).json(booking);
  } catch (error) {
    console.error('Error getting booking:', error);
    return res.status(500).json({ message: 'Failed to get booking' });
  }
};

// Get bookings without completed clinical notes
exports.getBookingsWithoutCompletedNotes = async (req, res) => {
  try {
    const { therapistId } = req.params;
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    // Check if user has permission to view these bookings
    if (req.user.role !== 'admin' && req.user.role !== 'staff') {
      if (req.user.role === 'therapist' && therapistId !== req.user.id) {
        return res.status(403).json({ message: 'You do not have permission to view these bookings' });
      }
    }

    // Get completed bookings that either don't have a clinical note or have an incomplete note
    const { count, rows: bookings } = await Booking.findAndCountAll({
      where: {
        therapistId,
        status: 'Completed'
      },
      include: [
        {
          model: Client,
          as: 'Client',
          include: {
            model: User,
            as: 'User',
            attributes: ['firstName', 'lastName', 'email']
          }
        },
        {
          model: ServiceOption,
          as: 'ServiceOption',
          attributes: ['id', 'duration', 'price'],
          include: [
            {
              model: Service,
              as: 'Service',
              attributes: ['id', 'name', 'description']
            }
          ]
        },
        {
          model: ClinicalNote,
          as: 'ClinicalNote',
          required: false,
          where: {
            [Op.or]: [
              { completed: false },
              { id: null }
            ]
          }
        }
      ],
      limit: parseInt(limit),
      offset: offset,
      order: [['bookingStartTime', 'DESC']],
      distinct: true
    });

    return res.status(200).json({
      bookings,
      total: count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    console.error('Error getting bookings without completed notes:', error);
    return res.status(500).json({ message: 'Failed to get bookings' });
  }
};

// Get bookings ready for clinical notes (confirmed, paid, with therapist assigned)
exports.getBookingsReadyForNotes = async (req, res) => {
  try {
    const { page = 1, limit = 10, therapistId } = req.query;
    const offset = (page - 1) * limit;
    const requestingUser = req.user;

    let whereClause = {
      status: 'Confirmed',
      paymentStatus: 'Paid',
      therapistId: { [Op.ne]: null } // Must have assigned therapist
    };

    // Role-based filtering
    if (requestingUser.role === 'therapist') {
      // Therapist sees only their assigned bookings
      const therapist = await Therapist.findOne({ where: { userId: requestingUser.id } });
      if (!therapist) {
        return res.status(404).json({ message: "Therapist profile not found." });
      }
      whereClause.therapistId = therapist.id;
    } else if (therapistId && therapistId !== 'all') {
      // Admin/Staff can filter by specific therapist
      whereClause.therapistId = therapistId;
    }

    const { count, rows: bookings } = await Booking.findAndCountAll({
      where: whereClause,
      include: [
        {
          model: Client,
          as: 'Client',
          include: {
            model: User,
            as: 'User',
            attributes: ['firstName', 'lastName', 'email']
          }
        },
        {
          model: Therapist,
          as: 'Therapist',
          include: {
            model: User,
            as: 'User',
            attributes: ['firstName', 'lastName']
          }
        },
        {
          model: ServiceOption,
          as: 'ServiceOption',
          attributes: ['id', 'duration', 'price'],
          include: [
            {
              model: Service,
              as: 'Service',
              attributes: ['id', 'name', 'description']
            }
          ]
        },
        {
          model: ClinicalNote,
          as: 'ClinicalNote',
          required: false // Left join to include bookings with or without notes
        }
      ],
      limit: parseInt(limit),
      offset: offset,
      order: [['bookingStartTime', 'ASC']], // Upcoming sessions first
      distinct: true
    });

    return res.status(200).json({
      bookings,
      total: count,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page)
    });

  } catch (error) {
    console.error('Error getting bookings ready for notes:', error);
    return res.status(500).json({ message: 'Failed to get bookings ready for notes' });
  }
};
// Enhanced updateBooking controller with email notifications
exports.updateBooking = async (req, res) => {
  const { id } = req.params;
  const {
    therapistId,
    serviceOptionId,
    bookingTime,
    status,
    internalNotes,
    paymentStatus,
    paymentMethod,
    priceAtBooking,
    cancellationReason,
    initiatedBy
  } = req.body;

  const transaction = await sequelize.transaction();

  try {
    // 1. Find the booking with all necessary associations
    const booking = await Booking.findByPk(id, {
      include: [
        { model: Client },
        { model: ServiceOption, include: [{ model: Service }] },
        { model: Therapist, include: [{ model: User }], required: false }
      ],
      transaction
    });

    if (!booking) {
      await transaction.rollback();
      return res.status(404).json({ message: "Booking not found." });
    }

    // Track changes for notifications
    const originalValues = {
      status: booking.status,
      therapistId: booking.therapistId,
      bookingStartTime: booking.bookingStartTime,
      bookingEndTime: booking.bookingEndTime,
      paymentStatus: booking.paymentStatus
    };

    // Handle cancellation separately if status is being changed to cancelled
    if (status && status.includes('Cancelled')) {
      await transaction.rollback(); // We'll handle this in the deleteBooking controller
      return this.deleteBooking(req, res);
    }

    // 2. If serviceOptionId or bookingTime or therapistId is being changed, validate new slot
    let newServiceOptionId = serviceOptionId || booking.serviceOptionId;
    let newTherapistId = (therapistId !== undefined) ? therapistId : booking.therapistId;
    
    // Align time parsing with createBooking
    let newBookingTime;
    if (bookingTime) {
      try {
        const timeParseResult = parseBookingTime(bookingTime);
        newBookingTime = timeParseResult.parsedTime;
      } catch (parseError) {
        await transaction.rollback();
        return res.status(400).json({ message: parseError.message });
      }
    } else {
      newBookingTime = booking.bookingStartTime;
    }

    // Check if time is being changed
    const isTimeChanged = bookingTime &&
      newBookingTime.getTime() !== originalValues.bookingStartTime.getTime();

    // Only validate if any of these fields are being changed
    if (serviceOptionId || bookingTime || (therapistId !== undefined)) {
      // Get ServiceOption details
      const serviceOption = await ServiceOption.findByPk(newServiceOptionId, { transaction });
      if (!serviceOption || !serviceOption.isActive) {
        await transaction.rollback();
        return res.status(404).json({ message: "Service option not found or inactive." });
      }

      const serviceId = serviceOption.serviceId;
      const serviceDuration = serviceOption.duration;
      
      // Use UTC time handling consistent with createBooking
      const { dateStr: bookingDateStr, timeStr: bookingStartTimeStr, dayNum: bookingDayNum } = parseBookingTime(newBookingTime);

      console.log('Booking update time details:', {
        inputTime: bookingTime,
        parsedTime: newBookingTime.toISOString(),
        dateStr: bookingDateStr,
        timeStr: bookingStartTimeStr,
        dayNum: bookingDayNum,
        therapistId: newTherapistId
      });

      // Find matching availability rule
      const availabilityWhere = {
        serviceId: serviceId,
        isActive: true,
        startTime: bookingStartTimeStr,
        [Op.or]: [
          { specificDate: bookingDateStr },
          { dayOfWeek: bookingDayNum, specificDate: null }
        ]
      };

      if (newTherapistId) {
        availabilityWhere[Op.and] = [
          {
            [Op.or]: [
              { therapistId: newTherapistId },
              { therapistId: null }
            ]
          }
        ];
      }

      const potentialRules = await ServiceAvailability.findAll({
        where: availabilityWhere,
        order: [["therapistId", "DESC"]],
        transaction
      });

      if (potentialRules.length === 0) {
        await transaction.rollback();
        
        // Debug query like in createBooking
        const debugRules = await ServiceAvailability.findAll({
          where: {
            serviceId: serviceId,
            isActive: true
          },
          transaction
        });
        
        return res.status(400).json({ 
          message: "No availability rule found for the selected service, time, and therapist.",
          debug: {
            searchedFor: {
              serviceId,
              startTime: bookingStartTimeStr,
              dayOfWeek: bookingDayNum,
              specificDate: bookingDateStr,
              therapistId: newTherapistId
            },
            availableRules: debugRules.map(rule => ({
              id: rule.id,
              startTime: rule.startTime,
              dayOfWeek: rule.dayOfWeek,
              specificDate: rule.specificDate,
              therapistId: rule.therapistId
            }))
          }
        });
      }

      const availabilityRule = potentialRules[0];

      // Check booking limit (exclude this booking itself)
      const currentBookingCount = await Booking.count({
        where: {
          serviceOptionId: newServiceOptionId,
          bookingStartTime: newBookingTime,
          therapistId: newTherapistId,
          id: { [Op.ne]: booking.id },
          status: { [Op.notIn]: ["Cancelled By Client", "Cancelled By Staff"] }
        },
        transaction
      });

      if (currentBookingCount >= availabilityRule.bookingLimit) {
        await transaction.rollback();
        return res.status(400).json({ message: "Sorry, this time slot is now fully booked." });
      }

      // Update booking fields
      booking.serviceOptionId = newServiceOptionId;
      booking.therapistId = newTherapistId;
      booking.bookingStartTime = newBookingTime;
      booking.bookingEndTime = addMinutes(newBookingTime, serviceDuration);

      // Only update price if explicitly changed
      if (priceAtBooking !== undefined && priceAtBooking !== booking.priceAtBooking) {
        booking.priceAtBooking = priceAtBooking;
      }
    }

    // 3. Update other fields
    if (status) booking.status = status;
    if (paymentStatus) {
      booking.paymentStatus = paymentStatus;

      if (paymentStatus === "Paid") {
        if (booking.status !== "Confirmed") {
          booking.status = "Confirmed";
        }

        const latestPayment = await Payment.findOne({
          where: { bookingId: booking.id },
          order: [['createdAt', 'DESC']],
          transaction
        });

        if (latestPayment) {
          latestPayment.status = "Succeeded";
          latestPayment.paidAt = new Date();
          await latestPayment.save({ transaction });
        }
      }
    }
    if (paymentMethod) booking.paymentMethod = paymentMethod;
    if (internalNotes !== undefined) booking.internalNotes = internalNotes;

    await booking.save({ transaction });
    await transaction.commit();

    // 4. Fetch fully updated booking with all associations
    const updatedBooking = await Booking.findByPk(id, {
      include: [
        { model: Client },
        { model: ServiceOption, include: [{ model: Service }] },
        { model: Therapist, include: [{ model: User, attributes: ["firstName", "lastName", "email"] }], required: false },
        { model: Payment }
      ]
    });

    // 5. Send appropriate notifications based on changes
    try {
      if (isTimeChanged) {
        await emailService.rescheduleBookingEmail(
          updatedBooking,
          updatedBooking.Client,
          updatedBooking.bookingStartTime,
          updatedBooking.bookingEndTime
        );
      }

      if (status === 'Confirmed' && originalValues.status !== 'Confirmed') {
        await sendBookingDetailsEmail(
          updatedBooking,
          updatedBooking.Client,
          updatedBooking.ServiceOption,
          updatedBooking.ServiceOption.Service
        );
      }
    } catch (emailError) {
      console.error('Error sending notification emails:', emailError);
    }

    // 6. Send response
    res.json({
      success: true,
      message: "Booking updated successfully" +
        (isTimeChanged ? ". Client has been notified of the schedule change." : ""),
      booking: updatedBooking
    });

  } catch (error) {
    await transaction.rollback();
    console.error("Error updating booking:", error);

    if (error.name === "SequelizeValidationError") {
      const messages = error.errors.map(err => err.message);
      return res.status(400).json({ message: "Validation Error", errors: messages });
    }

    res.status(500).json({
      message: "Server error while updating booking.",
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};
// Enhanced deleteBooking controller with email notifications
exports.deleteBooking = async (req, res) => {
  const { id } = req.params;
  const { cancellationReason, initiatedBy } = req.body;
  const transaction = await sequelize.transaction();

  try {
    // 1. Find the booking with associated client
    const booking = await Booking.findByPk(id, {
      include: [
        { model: Client },
        { model: ServiceOption, include: [{ model: Service }] },
        { model: Payment }
      ],
      transaction
    });

    if (!booking) {
      await transaction.rollback();
      return res.status(404).json({ message: "Booking not found." });
    }

    // 2. Validate cancellation is allowed
    if (booking.status === 'Cancelled By Client' || booking.status === 'Cancelled By Staff') {
      await transaction.rollback();
      return res.status(400).json({ message: "Booking is already cancelled." });
    }

    // 3. Determine cancellation status based on who initiated it
    const cancellationStatus = initiatedBy === 'client'
      ? 'Cancelled By Client'
      : 'Cancelled By Staff';

    // 4. Handle payment refund if applicable
    let refundResult = null;
    if (booking.paymentStatus === 'Paid' || booking.paymentStatus === 'Partially Refunded') {
      // Implement your actual refund logic here
      // For example with Stripe:
      // refundResult = await processRefund(booking);

      // Update payment status
      if (booking.Payment) {
        await Payment.update(
          { status: 'Refunded' },
          { where: { id: booking.Payment.id }, transaction }
        );
      }
      booking.paymentStatus = 'Refunded';
    }

    // 5. Update booking status
    await booking.update({
      status: cancellationStatus,
      cancellationReason: cancellationReason,
      cancellationTime: new Date(),
      paymentStatus: refundResult ? 'Refunded' : booking.paymentStatus
    }, { transaction });

    // 6. Commit transaction
    await transaction.commit();

    // 7. Send cancellation notification
    try {
      await emailService.sendCancellationEmail(booking, booking.Client);
    } catch (emailError) {
      console.error('Error sending cancellation email:', emailError);
      // Don't fail the request if email fails
    }

    // 8. Return success response
    res.json({
      success: true,
      message: `Booking ${cancellationStatus.toLowerCase()} successfully. Client has been notified.`,
      bookingId: booking.id,
      refund: refundResult,
      newStatus: cancellationStatus
    });

  } catch (error) {
    await transaction.rollback();
    console.error("Error cancelling booking:", error);

    if (error.name === 'SequelizeValidationError') {
      const messages = error.errors.map(err => err.message);
      return res.status(400).json({ message: "Validation Error", errors: messages });
    }

    res.status(500).json({
      message: "Server error while cancelling booking.",
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Helper function to calculate refund amount (example)
function calculateRefundAmount(booking) {
  // Implement your business logic for refund calculations
  // Example: Full refund if cancelled more than 24 hours before appointment
  const now = new Date();
  const hoursUntilAppointment = (booking.bookingStartTime - now) / (1000 * 60 * 60);

  if (hoursUntilAppointment > 24) {
    return Math.round(booking.priceAtBooking * 100); // Convert to cents for Stripe
  } else {
    return Math.round(booking.priceAtBooking * 100 * 0.5); // 50% refund
  }
}