const { Schedule, Therapist, User } = require("../models");
const { Op } = require("sequelize");
const { parseISO, isAfter, format, parse } = require("date-fns");

// Helper function to safely parse date strings
function safeParseDateString(dateInput) {
  if (!dateInput) return null;

  // If it's already a Date object, return it
  if (dateInput instanceof Date) {
    return dateInput;
  }

  // If it's a string, parse it
  if (typeof dateInput === 'string') {
    return parseISO(dateInput);
  }

  return null;
}

// Helper function to parse time string to Date object for comparison
const parseTimeToDate = (timeString) => {
  try {
    if (!timeString) return null;

    // Handle different time formats
    if (timeString.includes('T')) {
      // ISO 8601 format
      return parseISO(timeString);
    }

    // Handle HH:mm:ss or HH:mm format
    const timeRegex = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/;
    const match = timeString.match(timeRegex);

    if (!match) return null;

    const [, hours, minutes, seconds = '00'] = match;
    const today = new Date();
    today.setHours(parseInt(hours), parseInt(minutes), parseInt(seconds), 0);

    return today;
  } catch (error) {
    console.error('Error parsing time:', error);
    return null;
  }
};

// Format time for database storage
const formatTimeString = (dateObj) => {
  try {
    if (!dateObj || !(dateObj instanceof Date)) return null;

    const hours = dateObj.getHours().toString().padStart(2, '0');
    const minutes = dateObj.getMinutes().toString().padStart(2, '0');
    const seconds = dateObj.getSeconds().toString().padStart(2, '0');

    return `${hours}:${minutes}:${seconds}`;
  } catch (error) {
    console.error('Error formatting time:', error);
    return null;
  }
};

// Alternative: Direct time validation and formatting
const validateAndFormatTime = (timeString) => {
  if (!timeString) return null;

  // Handle HH:mm:ss format
  const timeRegex = /^([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/;
  if (timeRegex.test(timeString)) {
    return timeString;
  }

  // Handle HH:mm format - add seconds
  const shortTimeRegex = /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/;
  if (shortTimeRegex.test(timeString)) {
    return timeString + ':00';
  }

  return null;
};

// Check for schedule conflicts
const hasScheduleConflict = async (therapistId, startTime, endTime, specificDate = null, dayOfWeek = null, excludeId = null) => {
  try {
    const whereConditions = {
      therapistId,
      [Op.and]: [
        {
          [Op.or]: [
            // Check for time overlap: new start time is before existing end time
            {
              startTime: {
                [Op.lt]: endTime
              },
              endTime: {
                [Op.gt]: startTime
              }
            }
          ]
        }
      ]
    };

    // Add date/day conditions
    if (specificDate) {
      whereConditions.specificDate = specificDate;
    } else if (dayOfWeek !== null && dayOfWeek !== undefined) {
      whereConditions.dayOfWeek = dayOfWeek;
    }

    // Exclude current record if updating
    if (excludeId) {
      whereConditions.id = { [Op.ne]: excludeId };
    }

    const conflicts = await Schedule.findAll({
      where: whereConditions,
      include: [{
        model: Therapist,
        include: [{
          model: User,
          attributes: ['firstName', 'lastName']
        }]
      }]
    });

    return conflicts.length > 0;
  } catch (error) {
    console.error('Error checking schedule conflicts:', error);
    return false;
  }
};
// Helper function to get conflicts for response
async function getScheduleConflicts(therapistId, startTime, endTime, specificDate, dayOfWeek, excludeId = null) {
  const where = {
    therapistId,
    [Op.or]: []
  };

  // For specific date entries
  if (specificDate) {
    where[Op.or].push({
      specificDate: specificDate,
      [Op.and]: [
        { startTime: { [Op.lt]: endTime } },
        { endTime: { [Op.gt]: startTime } }
      ]
    });
  }

  // For recurring entries (dayOfWeek)
  if (dayOfWeek !== null && dayOfWeek !== undefined) {
    where[Op.or].push({
      dayOfWeek: dayOfWeek,
      [Op.and]: [
        { startTime: { [Op.lt]: endTime } },
        { endTime: { [Op.gt]: startTime } }
      ]
    });
  }

  if (excludeId) {
    where.id = { [Op.ne]: excludeId };
  }

  const conflicts = await Schedule.findAll({
    where,
    include: [{
      model: Therapist,
      attributes: ["id", "userId"],
      include: [{
        model: User,
        attributes: ["firstName", "lastName"]
      }]
    }]
  });

  return conflicts;
}

// --- Admin/Staff Controllers ---

// Get schedules for therapists (Admin/Staff)
exports.getSchedules = async (req, res) => {
  try {
    const { therapistId, startDate, endDate, page = 1, limit = 10, type } = req.query;

    const where = {};
    if (therapistId) where.therapistId = therapistId;
    if (type) where.type = type;

    if (startDate && endDate) {
      const parsedStartDate = safeParseDateString(startDate);
      const parsedEndDate = safeParseDateString(endDate);

      where[Op.or] = [
        // Specific date entries within the range
        {
          specificDate: { [Op.between]: [format(parsedStartDate, 'yyyy-MM-dd'), format(parsedEndDate, 'yyyy-MM-dd')] }
        },
        // Recurring entries (dayOfWeek is not null)
        {
          dayOfWeek: { [Op.not]: null },
          [Op.or]: [
            { recurrenceStartDate: { [Op.lte]: format(parsedEndDate, 'yyyy-MM-dd') } },
            { recurrenceStartDate: null }
          ],
          [Op.or]: [
            { recurrenceEndDate: { [Op.gte]: format(parsedStartDate, 'yyyy-MM-dd') } },
            { recurrenceEndDate: null }
          ]
        }
      ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: schedules } = await Schedule.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: offset,
      order: [["startTime", "ASC"]],
      include: [{
        model: Therapist,
        attributes: ["id", "userId"],
        include: [{
          model: User,
          attributes: ["firstName", "lastName"]
        }]
      }]
    });

    res.json({
      schedules,
      totalSchedules: count,
      currentPage: parseInt(page),
      totalPages: Math.ceil(count / parseInt(limit))
    });
  } catch (error) {
    console.error("Error fetching schedules:", error);
    res.status(500).json({ message: "Server error while fetching schedules." });
  }
};

// Check for schedule conflicts (Admin/Staff)
exports.checkConflicts = async (req, res) => {
  try {
    const { therapistId, startTime, endTime, specificDate, dayOfWeek, excludeId } = req.query;

    const conflicts = await getScheduleConflicts(
      therapistId,
      startTime,
      endTime,
      specificDate,
      dayOfWeek ? parseInt(dayOfWeek) : null,
      excludeId
    );

    res.json({ conflicts });
  } catch (error) {
    console.error("Error checking conflicts:", error);
    res.status(500).json({ message: "Server error while checking conflicts." });
  }
};

// Create schedule entry (Admin/Staff)
exports.createScheduleEntry = async (req, res) => {
  try {
    const {
      therapistId,
      type,
      dayOfWeek,
      specificDate,
      startTime,
      endTime,
      recurrenceStartDate,
      recurrenceEndDate,
      notes
    } = req.body;

    // Validation errors array
    const errors = [];

    // Validate required fields
    if (!therapistId) errors.push("Therapist is required");
    if (!type) errors.push("Schedule type is required");
    if (!startTime) errors.push("Start time is required");
    if (!endTime) errors.push("End time is required");

    // Validate type enum
    const validTypes = ["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"];
    if (type && !validTypes.includes(type)) {
      errors.push(`Invalid type. Must be one of: ${validTypes.join(', ')}`);
    }

    // Validate that either dayOfWeek or specificDate is provided, but not both
    if ((dayOfWeek !== null && dayOfWeek !== undefined) && specificDate) {
      errors.push("Cannot specify both dayOfWeek and specificDate");
    }

    if ((dayOfWeek === null || dayOfWeek === undefined) && !specificDate) {
      errors.push("Must specify either dayOfWeek (for recurring) or specificDate (for one-time entry)");
    }

    // Simple time format validation
    const timeRegex = /^([0-1]?[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/;
    if (startTime && !timeRegex.test(startTime)) {
      errors.push("Invalid start time format. Use HH:mm:ss");
    }
    if (endTime && !timeRegex.test(endTime)) {
      errors.push("Invalid end time format. Use HH:mm:ss");
    }

    // Validate time range (simple string comparison works for HH:mm:ss)
    if (startTime && endTime && startTime >= endTime) {
      errors.push("End time must be after start time");
    }

    // Return validation errors if any
    if (errors.length > 0) {
      return res.status(400).json({
        message: "Validation failed",
        errors
      });
    }

    // Create the schedule entry directly
    const scheduleData = {
      therapistId,
      type,
      dayOfWeek: dayOfWeek !== undefined ? dayOfWeek : null,
      specificDate: specificDate || null,
      startTime,
      endTime,
      recurrenceStartDate: recurrenceStartDate || null,
      recurrenceEndDate: recurrenceEndDate || null,
      notes: notes || null
    };

    const scheduleEntry = await Schedule.create(scheduleData);

    // Fetch the created entry with associations
    const createdEntry = await Schedule.findByPk(scheduleEntry.id, {
      include: [{
        model: Therapist,
        attributes: ["id", "userId"],
        include: [{
          model: User,
          attributes: ["firstName", "lastName"]
        }]
      }]
    });

    res.status(201).json(createdEntry);
  } catch (error) {
    console.error("Error creating schedule entry:", error);

    if (error.name === 'SequelizeValidationError') {
      const messages = error.errors.map(err => err.message);
      return res.status(400).json({
        message: "Database validation error",
        errors: messages
      });
    }

    if (error.name === 'SequelizeForeignKeyConstraintError') {
      return res.status(400).json({
        message: "Invalid therapist ID",
        errors: ["The specified therapist does not exist"]
      });
    }

    res.status(500).json({
      message: "Server error while creating schedule entry",
      errors: ["An unexpected error occurred"]
    });
  }
};

// Update schedule entry (Admin/Staff)
exports.updateScheduleEntry = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = { ...req.body };

    const scheduleEntry = await Schedule.findByPk(id);
    if (!scheduleEntry) {
      return res.status(404).json({ message: "Schedule entry not found." });
    }

    // Validate type enum if provided
    if (updateData.type) {
      const validTypes = ["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"];
      if (!validTypes.includes(updateData.type)) {
        return res.status(400).json({ message: `Invalid type. Must be one of: ${validTypes.join(', ')}` });
      }
    }

    // Parse time strings if provided
    if (updateData.startTime) {
      updateData.startTime = formatTimeString(parseTimeToDate(updateData.startTime));
    }
    if (updateData.endTime) {
      updateData.endTime = formatTimeString(parseTimeToDate(updateData.endTime));
    }

    const finalStartTime = updateData.startTime || scheduleEntry.startTime;
    const finalEndTime = updateData.endTime || scheduleEntry.endTime;

    // Validate time range if times are being updated
    if ((updateData.startTime || updateData.endTime)) {
      const startTimeDate = parseTimeToDate(finalStartTime);
      const endTimeDate = parseTimeToDate(finalEndTime);
      if (!isAfter(endTimeDate, startTimeDate)) {
        return res.status(400).json({ message: "End time must be after start time." });
      }
    }

    // Determine final values for conflict checking
    const finalSpecificDate = updateData.specificDate !== undefined ? updateData.specificDate : scheduleEntry.specificDate;
    const finalDayOfWeek = updateData.dayOfWeek !== undefined ? updateData.dayOfWeek : scheduleEntry.dayOfWeek;

    // Check for schedule conflicts, excluding this entry
    if ((updateData.startTime || updateData.endTime || updateData.specificDate !== undefined || updateData.dayOfWeek !== undefined) &&
      await hasScheduleConflict(scheduleEntry.therapistId, finalStartTime, finalEndTime, finalSpecificDate, finalDayOfWeek, id)) {
      return res.status(400).json({ message: "This time slot conflicts with an existing schedule." });
    }

    const updatedEntry = await scheduleEntry.update(updateData);

    // Fetch updated entry with associations
    const result = await Schedule.findByPk(updatedEntry.id, {
      include: [{
        model: Therapist,
        attributes: ["id", "userId"],
        include: [{
          model: User,
          attributes: ["firstName", "lastName"]
        }]
      }]
    });

    res.json(result);
  } catch (error) {
    console.error("Error updating schedule entry:", error);
    if (error.name === 'SequelizeValidationError') {
      const messages = error.errors.map(err => err.message);
      return res.status(400).json({ message: "Validation Error", errors: messages });
    }
    res.status(500).json({ message: "Server error while updating schedule entry." });
  }
};

// Delete schedule entry (Admin/Staff)
exports.deleteScheduleEntry = async (req, res) => {
  try {
    const { id } = req.params;

    const scheduleEntry = await Schedule.findByPk(id);
    if (!scheduleEntry) {
      return res.status(404).json({ message: "Schedule entry not found." });
    }

    await scheduleEntry.destroy();
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting schedule entry:", error);
    res.status(500).json({ message: "Server error while deleting schedule entry." });
  }
};

// --- Therapist Controllers ---

// Get current therapist's schedule
exports.getMySchedules = async (req, res) => {
  try {
    const therapistUserId = req.user.id;
    const { page = 1, limit = 10, startDate, endDate } = req.query;

    const therapist = await Therapist.findOne({ where: { userId: therapistUserId } });
    if (!therapist) {
      return res.status(404).json({ 
        message: "Therapist profile not found.",
        errors: ["Therapist profile not found"]
      });
    }

    const whereClause = { therapistId: therapist.id };
    
    // Add date filtering if provided
    if (startDate || endDate) {
      whereClause[Op.or] = [];
      
      if (startDate && endDate) {
        // For specific date entries
        whereClause[Op.or].push({
          specificDate: {
            [Op.between]: [startDate, endDate]
          }
        });
        
        // For recurring entries (always include them in date range queries)
        whereClause[Op.or].push({
          dayOfWeek: { [Op.not]: null },
          specificDate: null
        });
      }
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    const { count, rows } = await Schedule.findAndCountAll({
      where: whereClause,
      limit: parseInt(limit),
      offset: offset,
      order: [['createdAt', 'DESC']]
    });

    res.json({
      schedules: rows,
      totalSchedules: count,
      currentPage: parseInt(page),
      totalPages: Math.ceil(count / parseInt(limit))
    });
  } catch (error) {
    console.error("Error fetching therapist schedules:", error);
    res.status(500).json({ 
      message: "Server error while fetching schedules.",
      errors: [error.message]
    });
  }
};

// 4. Improve error handling in updateMyScheduleEntry
exports.updateMyScheduleEntry = async (req, res) => {
  try {
    const therapistUserId = req.user.id;
    const { id } = req.params;
    const updateData = { ...req.body };

    const therapist = await Therapist.findOne({ where: { userId: therapistUserId } });
    if (!therapist) {
      return res.status(404).json({ 
        message: "Therapist profile not found.",
        errors: ["Therapist profile not found"]
      });
    }

    const scheduleEntry = await Schedule.findOne({
      where: { id, therapistId: therapist.id }
    });
    if (!scheduleEntry) {
      return res.status(404).json({ 
        message: "Schedule entry not found or not owned by you.",
        errors: ["Schedule entry not found"]
      });
    }

    const errors = [];

    // Validate type enum if provided
    if (updateData.type) {
      const validTypes = ["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"];
      if (!validTypes.includes(updateData.type)) {
        errors.push(`Invalid type. Must be one of: ${validTypes.join(', ')}`);
      }
    }

    // Parse time strings if provided
    if (updateData.startTime) {
      const parsed = formatTimeString(parseTimeToDate(updateData.startTime));
      if (!parsed) {
        errors.push("Invalid startTime format");
      } else {
        updateData.startTime = parsed;
      }
    }
    
    if (updateData.endTime) {
      const parsed = formatTimeString(parseTimeToDate(updateData.endTime));
      if (!parsed) {
        errors.push("Invalid endTime format");
      } else {
        updateData.endTime = parsed;
      }
    }

    if (errors.length > 0) {
      return res.status(400).json({ 
        message: "Validation errors occurred",
        errors 
      });
    }

    const finalStartTime = updateData.startTime || scheduleEntry.startTime;
    const finalEndTime = updateData.endTime || scheduleEntry.endTime;

    // Validate time range if times are being updated
    if ((updateData.startTime || updateData.endTime)) {
      const startTimeDate = parseTimeToDate(finalStartTime);
      const endTimeDate = parseTimeToDate(finalEndTime);
      if (!isAfter(endTimeDate, startTimeDate)) {
        return res.status(400).json({ 
          message: "End time must be after start time.",
          errors: ["End time must be after start time"]
        });
      }
    }

    // Determine final values for conflict checking
    const finalSpecificDate = updateData.specificDate !== undefined ? updateData.specificDate : scheduleEntry.specificDate;
    const finalDayOfWeek = updateData.dayOfWeek !== undefined ? updateData.dayOfWeek : scheduleEntry.dayOfWeek;

    // Check for schedule conflicts, excluding this entry
    if ((updateData.startTime || updateData.endTime || updateData.specificDate !== undefined || updateData.dayOfWeek !== undefined) &&
      await hasScheduleConflict(therapist.id, finalStartTime, finalEndTime, finalSpecificDate, finalDayOfWeek, id)) {
      return res.status(400).json({ 
        message: "This time slot conflicts with your existing schedule.",
        errors: ["Schedule conflict detected"]
      });
    }

    const updatedEntry = await scheduleEntry.update(updateData);
    res.json(updatedEntry);
  } catch (error) {
    console.error("Error updating schedule entry:", error);
    if (error.name === 'SequelizeValidationError') {
      const messages = error.errors.map(err => err.message);
      return res.status(400).json({ 
        message: "Validation Error", 
        errors: messages 
      });
    }
    res.status(500).json({ 
      message: "Server error while updating schedule entry.",
      errors: [error.message]
    });
  }
};

// Check conflicts for current therapist
exports.checkMyConflicts = async (req, res) => {
  try {
    const therapistUserId = req.user.id;
    const { startTime, endTime, specificDate, dayOfWeek, excludeId } = req.query;

    const therapist = await Therapist.findOne({ where: { userId: therapistUserId } });
    if (!therapist) {
      return res.status(404).json({ message: "Therapist profile not found." });
    }

    const conflicts = await getScheduleConflicts(
      therapist.id,
      startTime,
      endTime,
      specificDate,
      dayOfWeek ? parseInt(dayOfWeek) : null,
      excludeId
    );

    res.json({ conflicts });
  } catch (error) {
    console.error("Error checking therapist conflicts:", error);
    res.status(500).json({ message: "Server error while checking conflicts." });
  }
};

// Add schedule entry for current therapist
exports.addMyScheduleEntry = async (req, res) => {
  try {
    const therapistUserId = req.user.id;
    const {
      type,
      dayOfWeek,
      specificDate,
      startTime,
      endTime,
      recurrenceStartDate,
      recurrenceEndDate,
      notes
    } = req.body;

    const therapist = await Therapist.findOne({ where: { userId: therapistUserId } });
    if (!therapist) {
      return res.status(404).json({
        message: "Therapist profile not found.",
        errors: ["Therapist profile not found"]
      });
    }

    // Collect validation errors
    const errors = [];

    // Validate required fields
    if (!type) errors.push("type is required");
    if (!startTime) errors.push("startTime is required");
    if (!endTime) errors.push("endTime is required");

    // Validate type enum
    const validTypes = ["WorkingHours", "TimeOff", "SpecificAvailability", "BlockedSlot"];
    if (type && !validTypes.includes(type)) {
      errors.push(`Invalid type. Must be one of: ${validTypes.join(', ')}`);
    }

    // Validate that either dayOfWeek or specificDate is provided, but not both
    if ((dayOfWeek !== null && dayOfWeek !== undefined) && specificDate) {
      errors.push("Cannot specify both dayOfWeek and specificDate. Use dayOfWeek for recurring entries, specificDate for one-time entries.");
    }

    if ((dayOfWeek === null || dayOfWeek === undefined) && !specificDate) {
      errors.push("Must specify either dayOfWeek (for recurring) or specificDate (for one-time entry).");
    }

    // Return validation errors if any
    if (errors.length > 0) {
      return res.status(400).json({
        message: "Validation errors occurred",
        errors
      });
    }

    // Parse and validate time strings
    const parsedStartTime = formatTimeString(parseTimeToDate(startTime));
    const parsedEndTime = formatTimeString(parseTimeToDate(endTime));

    if (!parsedStartTime || !parsedEndTime) {
      return res.status(400).json({
        message: "Invalid time format. Use HH:mm:ss or ISO 8601 format.",
        errors: ["Invalid time format for startTime or endTime"]
      });
    }

    // Validate time range
    const startTimeDate = parseTimeToDate(startTime);
    const endTimeDate = parseTimeToDate(endTime);
    if (!isAfter(endTimeDate, startTimeDate)) {
      return res.status(400).json({
        message: "End time must be after start time.",
        errors: ["End time must be after start time"]
      });
    }

    // Check for schedule conflicts
    if (await hasScheduleConflict(therapist.id, parsedStartTime, parsedEndTime, specificDate, dayOfWeek)) {
      return res.status(400).json({
        message: "This time slot conflicts with your existing schedule.",
        errors: ["Schedule conflict detected"]
      });
    }

    const scheduleData = {
      therapistId: therapist.id,
      type,
      dayOfWeek: dayOfWeek !== undefined ? dayOfWeek : null,
      specificDate: specificDate || null,
      startTime: parsedStartTime,
      endTime: parsedEndTime,
      recurrenceStartDate: recurrenceStartDate || null,
      recurrenceEndDate: recurrenceEndDate || null,
      notes: notes || null
    };

    const scheduleEntry = await Schedule.create(scheduleData);

    res.status(201).json(scheduleEntry);
  } catch (error) {
    console.error("Error adding schedule entry:", error);
    if (error.name === 'SequelizeValidationError') {
      const messages = error.errors.map(err => err.message);
      return res.status(400).json({
        message: "Validation Error",
        errors: messages
      });
    }
    res.status(500).json({
      message: "Server error while adding schedule entry.",
      errors: [error.message]
    });
  }
};

// Delete current therapist's schedule entry
exports.deleteMyScheduleEntry = async (req, res) => {
  try {
    const therapistUserId = req.user.id;
    const { id } = req.params;

    const therapist = await Therapist.findOne({ where: { userId: therapistUserId } });
    if (!therapist) {
      return res.status(404).json({ message: "Therapist profile not found." });
    }

    const scheduleEntry = await Schedule.findOne({
      where: { id, therapistId: therapist.id }
    });
    if (!scheduleEntry) {
      return res.status(404).json({ message: "Schedule entry not found or not owned by you." });
    }

    await scheduleEntry.destroy();
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting schedule entry:", error);
    res.status(500).json({ message: "Server error while deleting schedule entry." });
  }
};

