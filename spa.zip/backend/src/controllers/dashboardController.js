// controllers/dashboardController.js

const { Booking, Payment, Therapist, Client, User, sequelize } = require("../models");
const { Op } = require("sequelize");
const { startOfDay, endOfDay, subDays, formatISO, parseISO } = require("date-fns");
const reportController = require("./reportController");

exports.getOverview = async (req, res) => {
  try {
    // 1. Today's Sessions & Change
    const today = new Date();
    const yesterday = subDays(today, 1);

    const todayStart = startOfDay(today);
    const todayEnd = endOfDay(today);
    const yestStart = startOfDay(yesterday);
    const yestEnd = endOfDay(yesterday);

    // Today's sessions
    const todaySessions = await Booking.count({
      where: {
        bookingStartTime: { [Op.between]: [todayStart, todayEnd] },
        status: { [Op.in]: ["Confirmed", "Completed"] }
      }
    });
    // Yesterday's sessions (for % change)
    const yestSessions = await Booking.count({
      where: {
        bookingStartTime: { [Op.between]: [yestStart, yestEnd] },
        status: { [Op.in]: ["Confirmed", "Completed"] }
      }
    });
    const sessionChange = yestSessions ? (((todaySessions - yestSessions) / yestSessions) * 100).toFixed(1) : 0;

    // 2. Revenue & Change
    const todayRevenue = await Payment.sum('amount', {
      where: {
        status: "Succeeded",
        paidAt: { [Op.between]: [todayStart, todayEnd] }
      }
    }) || 0;
    const yestRevenue = await Payment.sum('amount', {
      where: {
        status: "Succeeded",
        paidAt: { [Op.between]: [yestStart, yestEnd] }
      }
    }) || 0;
    const revenueChange = yestRevenue ? (((todayRevenue - yestRevenue) / yestRevenue) * 100).toFixed(1) : 0;

    // 3. Retention Rate (clients with >1 booking / total clients)
    const totalClients = await Client.count();
    const repeatClients = await Booking.findAll({
      attributes: ['clientId'],
      group: ['clientId'],
      having: sequelize.literal('COUNT(*) > 1')
    });
    const retentionRate = totalClients ? ((repeatClients.length / totalClients) * 100).toFixed(1) : 0;
    const retentionChange = 0; // Could compare with previous period if desired

    // 4. Therapist Utilization (sessions today / total therapists)
    const totalTherapists = await Therapist.count({ where: { isActive: true } });
    const utilizationRate = totalTherapists ? ((todaySessions / totalTherapists) * 100).toFixed(1) : 0;
    const utilizationChange = 0;

    // 5. Upcoming Sessions (next 4)
    const upcomingSessions = await Booking.findAll({
      where: {
        bookingStartTime: { [Op.gte]: new Date() },
        status: { [Op.in]: ["Confirmed", "Pending Confirmation"] }
      },
      include: [
        { model: Client, attributes: ["firstName", "lastName"] },
        { model: Therapist, include: [{ model: User, attributes: ["firstName", "lastName"] }] }
      ],
      order: [["bookingStartTime", "ASC"]],
      limit: 4
    });

    // 6. Therapist Availability (example: random % and today's sessions per therapist)
    const therapists = await Therapist.findAll({
      where: { isActive: true },
      include: [{ model: User, attributes: ["firstName", "lastName"] }]
    });

    const therapistAvailability = await Promise.all(
      therapists.map(async t => {
        const sessionsToday = await Booking.count({
          where: {
            therapistId: t.id,
            bookingStartTime: { [Op.between]: [todayStart, todayEnd] },
            status: { [Op.in]: ["Confirmed", "Completed"] }
          }
        });
        return {
          name: `${t.User.firstName} ${t.User.lastName}`,
          availability: Math.floor(Math.random() * 40) + 60, // 60-100%
          sessions: sessionsToday,
          rating: (Math.random() * 1.5 + 3.5).toFixed(1) // 3.5-5.0
        };
      })
    );

    // Format upcoming sessions for frontend
    const formattedSessions = upcomingSessions.map(s => ({
      id: s.id,
      client: `${s.Client.firstName} ${s.Client.lastName}`,
      therapist: s.Therapist ? `${s.Therapist.User.firstName} ${s.Therapist.User.lastName}` : "Unassigned",
      time: new Date(s.bookingStartTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      service: s.serviceName || "Session",
      avatar: s.Client.firstName[0]
    }));

    // 7. Revenue Chart (last 14 days) using your reportController
    const chartStart = formatISO(startOfDay(subDays(today, 13)), { representation: 'date' });
    const chartEnd = formatISO(endOfDay(today), { representation: 'date' });
    const revenueChartData = await getRevenueChartData(chartStart, chartEnd);

    res.json({
      todaySessions,
      sessionChange,
      revenue: todayRevenue,
      revenueChange,
      retentionRate,
      retentionChange,
      utilizationRate,
      utilizationChange,
      upcomingSessions: formattedSessions,
      therapistAvailability,
      revenueChart: revenueChartData
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    res.status(500).json({ error: "Dashboard data fetch failed" });
  }
};

// Helper to call getRevenueReport as a function and format chart data
async function getRevenueChartData(startDate, endDate) {
  // Use your reportController logic
  // We simulate req/res to get the result as a function
  const req = { query: { startDate, endDate } };
  let jsonData;
  const res = {
    json: (data) => { jsonData = data; },
    status: () => res,
  };
  await reportController.getRevenueReport(req, res);

  // Format for chart: [{ date: 'YYYY-MM-DD', revenue: 123 }, ...]
  if (!jsonData || !Array.isArray(jsonData.dailyRevenue)) return [];
  const revenueMap = {};
  jsonData.dailyRevenue.forEach(row => {
    // row.date might be a Date object or string
    const date = typeof row.date === 'string' ? row.date : row.date.toISOString().slice(0, 10);
    revenueMap[date] = parseFloat(row.totalRevenue);
  });

  const chartData = [];
  for (let i = 0; i < 14; i++) {
    const d = formatISO(subDays(endOfDay(parseISO(endDate)), 13 - i), { representation: 'date' });
    chartData.push({
      date: d,
      revenue: revenueMap[d] || 0
    });
  }
  return chartData;
}
